package feature;

/**
 * Empty class - required in order to have src/main/java folder checked in.
 */
public class Empty {

}
