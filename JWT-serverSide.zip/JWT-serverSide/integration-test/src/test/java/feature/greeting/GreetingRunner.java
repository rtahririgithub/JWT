package feature.greeting;

import org.junit.runner.RunWith;

import com.intuit.karate.junit4.Karate;

/**
 * Test class for 'greeting.feature' scenarios.
 */
@RunWith(Karate.class)
public class GreetingRunner {

}
